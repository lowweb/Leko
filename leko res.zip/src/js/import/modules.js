import "%modules%/tabmenu/tabmenu";
import "%modules%/contract-menu/contract-menu";
import "%modules%/btn/btn";
import "%modules%/calculator/calculator";
import "%modules%/ham/ham";
