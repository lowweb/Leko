document.getElementById("btn-scroll").onclick = function() {
	document.getElementById('calc').scrollIntoView({block: 'start',behavior: 'smooth' });
};